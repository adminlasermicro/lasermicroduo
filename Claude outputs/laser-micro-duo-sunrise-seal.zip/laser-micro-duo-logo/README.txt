Laser Micro Duo logo: Sunrise Seal, Clay & Ink palette (November 2026)

All lettering is converted to shapes (Fraunces SemiBold and Plus Jakarta Sans Bold),
so no fonts are needed to open, print or embroider these files.

MAIN LOGO (the seal)
  lmd-seal.svg / .png                  Clay seal for light backgrounds. Packaging, social posts, About page.
  lmd-seal-on-dark.svg / .png          For ink or dark backgrounds.
  lmd-seal-one-color-ink.svg / .png    Single-color version for stamps, engraving, one-color printing.

WEBSITE HEADER, EMAIL, INVOICES
  lmd-logo-horizontal.svg / .png       Sun icon + "Laser Micro Duo", for light backgrounds.
  lmd-logo-horizontal-on-dark.svg/.png For dark backgrounds (footer).

ICONS (the seal's text is too small to read under about 80 px, so use these instead)
  lmd-icon.svg / lmd-icon-512.png      Round sun icon.
  lmd-app-icon.svg / -512 / -1024.png  Square icon for the Wix site icon and social profile pictures.
  favicon.svg, favicon-32.png          Browser tab icon.
  apple-touch-icon.png                 iPhone home-screen icon (180 px).

COLORS
  Clay #9E4428 (seal band, buttons)   Ink #1C2230 (text, rays, dark backgrounds)
  Cream #FBF8F4 (background)          Gold #D9A441 (accents and the small-size sun)

RULES
  Clear space: at least one-tenth of the seal's width on every side.
  Minimum size: seal 1 inch / 96 px wide. Smaller than that, use the icon.
  Don't stretch, recolor outside the palette, add shadows or put the seal on busy photos.
