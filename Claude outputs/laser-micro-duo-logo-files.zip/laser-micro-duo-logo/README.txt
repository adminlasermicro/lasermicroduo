Laser Micro Duo logo, direction A ("The Trio") - final files, November 2026

Text is converted to outlines (Plus Jakarta Sans Bold), so no font is needed to open or print these.

WEBSITE
  laser-micro-duo-logo.svg            Main logo, light backgrounds (site header, emails)
  laser-micro-duo-logo-inverse.svg    For dark backgrounds (footer)
  favicon.svg, favicon-32.png         Browser tab icon
  apple-touch-icon.png                iPhone home screen (180 px)

WIX / SOCIAL
  laser-micro-duo-app-icon.svg / -512.png / -1024.png   Site icon, profile pictures

PRINT AND STICKERS
  laser-micro-duo-logo-stacked.svg / -inverse.svg   Square spaces, packaging
  laser-micro-duo-logo-black.svg / -white.svg       One-color printing, engraving

PNG versions of the main logos are high-resolution with transparent backgrounds.

Colors: dots #b9cbbf and #3c6e5b, word #1f2b26. On dark: word white, center dot #9cbfae.
Clear space: the width of the big dot on every side. Minimum size: 120 px wide on screen, 1 inch in print.
